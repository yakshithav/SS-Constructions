sap.ui.define([

], () => {
	"use strict";

	QUnit.module("First Test", {});

	QUnit.test("It's just true", (assert) => {
		assert.strictEqual(true, true);
	});
});
