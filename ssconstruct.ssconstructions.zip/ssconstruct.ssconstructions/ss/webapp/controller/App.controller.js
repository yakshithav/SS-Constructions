sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("ss.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  